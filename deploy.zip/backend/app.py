"""
信息茧房推演系统 - 后端主入口
Ascend 环境运行提示:
  1. conda activate info-cocoon  # 激活环境
  2. uvicorn backend.app:app --reload --host 0.0.0.0 --port 8000
"""
import asyncio
import json
import logging
import os
from typing import Dict, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from . import state
from .helpers import calculate_max_concurrent, _state_to_dict
from .routers import simulation as sim_router
from .routers import report as report_router
from .routers import event as event_router
from .routers import prediction as pred_router
from .routers import profiles as profiles_router
from .routers import settings as settings_router
from .llm.client import LLMConfig
from .simulation.engine import SimulationEngine
from .simulation.engine_dual import SimulationEngineDual
from .simulation.realistic_population import load_realistic_population
from .config.runtime_settings import bootstrap_runtime_settings

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)
active_websockets: Dict[str, WebSocket] = {}

bootstrap_runtime_settings()

app = FastAPI(
    title="信息茧房推演系统",
    description="模拟算法推荐与权威回应对群体观点的影响",
    version="3.0.0"
)

# CORS 配置：支持环境变量配置允许的源
# 生产环境应设置 CORS_ALLOWED_ORIGINS 环境变量，如 "https://example.com,https://api.example.com"
# 开发环境默认允许 localhost
_cors_origins_str = os.getenv("CORS_ALLOWED_ORIGINS", "")
if _cors_origins_str:
    CORS_ALLOWED_ORIGINS = [origin.strip() for origin in _cors_origins_str.split(",") if origin.strip()]
else:
    # 开发环境默认值
    CORS_ALLOWED_ORIGINS = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    # Issue #1256: 添加更多常用请求头
    allow_headers=["Content-Type", "Authorization", "Accept", "Accept-Encoding", "X-Requested-With", "X-Request-ID"],
)

# 启动时检查 CORS 安全配置
if "*" in CORS_ALLOWED_ORIGINS:
    logger.warning("CORS允许所有来源(*), 不建议在生产环境使用!")

# 注册路由
app.include_router(sim_router.router)
app.include_router(report_router.router)
app.include_router(event_router.router)
app.include_router(pred_router.router)
app.include_router(profiles_router.router)
app.include_router(settings_router.router)


@app.get("/")
async def root():
    """健康检查"""
    return {"status": "ok", "service": "信息茧房推演系统", "version": "3.0.0"}


@app.get("/api/health/llm")
async def llm_health():
    """探测 LLM 端点可达性，返回连接状态供前端展示。"""
    import aiohttp as _aiohttp
    from urllib.parse import urlparse

    base_url = os.getenv("LLM_BASE_URL", "").strip()
    api_key = os.getenv("LLM_API_KEY", "").strip()
    model = os.getenv("LLM_MODEL", "")

    if not base_url:
        return {
            "status": "not_configured",
            "base_url": "",
            "model": model,
            "message": "未配置 LLM_BASE_URL",
        }

    # localhost 视为可用（Ollama 等本地服务不走远程探测）
    if "localhost" in base_url or "127.0.0.1" in base_url or "::1" in base_url:
        return {
            "status": "ok",
            "base_url": base_url,
            "model": model,
            "message": "本地 LLM 服务",
        }

    # 远程端点：HEAD 探测
    try:
        parsed = urlparse(base_url)
        probe_url = f"{parsed.scheme}://{parsed.netloc}"
        timeout = _aiohttp.ClientTimeout(total=3)
        async with _aiohttp.ClientSession(timeout=timeout) as session:
            async with session.head(probe_url) as resp:
                if resp.status < 500:
                    return {
                        "status": "ok",
                        "base_url": base_url,
                        "model": model,
                        "message": f"LLM 端点可达 (HTTP {resp.status})",
                    }
                else:
                    return {
                        "status": "error",
                        "base_url": base_url,
                        "model": model,
                        "message": f"LLM 端点返回 HTTP {resp.status}",
                    }
    except _aiohttp.ClientConnectorError:
        return {
            "status": "unreachable",
            "base_url": base_url,
            "model": model,
            "message": "无法连接到 LLM 端点",
        }
    except (asyncio.TimeoutError, _aiohttp.ServerTimeoutError):
        return {
            "status": "unreachable",
            "base_url": base_url,
            "model": model,
            "message": "LLM 端点连接超时",
        }
    except Exception as e:
        return {
            "status": "error",
            "base_url": base_url,
            "model": model,
            "message": f"探测失败: {type(e).__name__}",
        }


# ==================== WebSocket ====================

@app.websocket("/ws/simulation")
async def websocket_simulation(websocket: WebSocket):
    """
    WebSocket 实时推送推演过程

    协议:
    - 客户端 -> 服务端:
        {"action": "start", "params": {...}}
        {"action": "step"}
        {"action": "auto", "interval": 2000}  # 自动推演
        {"action": "stop"}
    - 服务端 -> 客户端:
        {"type": "state", "data": {...}}
        {"type": "progress", "step": 1, "total": 200, "message": "Agent 1/200"}
        {"type": "error", "message": "..."}
    """
    await websocket.accept()
    client_key = websocket.client.host if websocket.client else "unknown"
    previous_ws = active_websockets.get(client_key)
    if previous_ws is not None and previous_ws is not websocket:
        try:
            await previous_ws.close(code=4000, reason="newer connection opened")
        except Exception:
            pass
    active_websockets[client_key] = websocket
    logger.info("WebSocket 连接已建立")

    auto_mode = False
    auto_task: Optional[asyncio.Task] = None
    max_steps = 50  # 默认值，会在start action中被更新

    async def send_progress(step: int, total: int, agent_id: int = None, agent_opinion: float = None):
        """发送进度更新"""
        try:
            # 构建进度消息
            progress_data = {
                "type": "progress",
                "step": step,
                "total": total,
                "percentage": round(step / total * 100, 1) if total > 0 else 0,
                "current_step": state.engine.step_count if state.engine else 0,
                "max_steps": max_steps
            }

            # 添加 Agent 详细信息
            if agent_id is not None:
                progress_data["agent_id"] = agent_id
                progress_data["agent_opinion"] = round(agent_opinion, 2) if agent_opinion is not None else 0

                # 根据观点值判断立场
                if agent_opinion is not None:
                    if agent_opinion < -0.3:
                        stance = "误信"
                    elif agent_opinion > 0.3:
                        stance = "正确认知"
                    else:
                        stance = "中立"
                    progress_data["agent_stance"] = stance

            progress_data["message"] = f"正在推演 Agent {step}/{total}" + (f" (ID:{agent_id})" if agent_id is not None else "")

            await websocket.send_json(progress_data)
        except (WebSocketDisconnect, RuntimeError):
            raise
        except Exception as e:
            logger.debug(f"发送进度失败: {e}")

    async def safe_send_json(payload: dict) -> bool:
        try:
            await websocket.send_json(payload)
            return True
        except (WebSocketDisconnect, RuntimeError) as e:
            logger.info(f"WebSocket已断开，停止发送: {e}")
            return False

    async def auto_step_loop(interval: int):
        """自动推演循环"""
        nonlocal max_steps
        while auto_mode and state.engine and state.engine.step_count < max_steps:
            try:
                # 如果事件注入正在进行，等待注入完成
                if state.injection_in_progress:
                    logger.debug("事件注入进行中，推演等待...")
                    if not await safe_send_json({
                        "type": "progress",
                        "message": "事件注入解析中，推演暂停等待..."
                    }):
                        break
                    # 等待注入完成（可配置超时，默认120秒）
                    injection_timeout = int(os.environ.get("INJECTION_TIMEOUT", "120"))
                    for _ in range(injection_timeout):
                        if not state.injection_in_progress:
                            break
                        await asyncio.sleep(1)
                    if state.injection_in_progress:
                        logger.warning("事件注入超时，恢复推演")
                    else:
                        logger.info("事件注入完成，恢复推演")
                        if not await safe_send_json({
                            "type": "progress",
                            "message": "事件注入完成，恢复推演"
                        }):
                            break

                s = await state.engine.async_step()
                if not await safe_send_json({
                    "type": "state",
                    "data": _state_to_dict(s)
                }):
                    break
                await asyncio.sleep(interval / 1000)
            except asyncio.CancelledError:
                logger.info("自动推演任务已取消")
                break
            except (WebSocketDisconnect, RuntimeError) as e:
                logger.info(f"自动推演连接已断开: {e}")
                break
            except Exception as e:
                logger.error(f"自动推演错误: {e}")
                await safe_send_json({
                    "type": "error",
                    "message": str(e)
                })
                break

    try:
        # Issue #1255: 添加消息速率限制
        from collections import deque
        message_timestamps: deque = deque(maxlen=100)  # 记录最近100条消息时间戳
        rate_limit = int(os.getenv("WS_RATE_LIMIT", "60"))  # 每分钟最大消息数
        rate_window = 60  # 1分钟窗口
        
        while True:
            data = await websocket.receive_text()
            import time
            current_time = time.time()
            message_timestamps.append(current_time)
            
            # 清理超过窗口的消息
            cutoff_time = current_time - rate_window
            while message_timestamps and message_timestamps[0] < cutoff_time:
                message_timestamps.popleft()
            
            # 检查速率限制
            if len(message_timestamps) > rate_limit:
                logger.warning(f"WebSocket消息速率超限: {len(message_timestamps)}/{rate_window}s")
                await websocket.send_json({"type": "error", "message": f"Rate limit: max {rate_limit} messages per minute"})
                continue
            
            # issue #736: 添加 JSON 解析和类型校验
            try:
                msg = json.loads(data)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "Invalid JSON"})
                continue
            if not isinstance(msg, dict) or not isinstance(msg.get("action"), str):
                await websocket.send_json({"type": "error", "message": "Message must be a JSON object with 'action' string"})
                continue
            action = msg["action"]
            params = msg.get("params", {})
            if not isinstance(params, dict):
                await websocket.send_json({"type": "error", "message": "'params' must be a JSON object"})
                continue

            if action == "start":
                # 启动新模拟
                use_llm = params.get("use_llm", True)
                population_size = params.get("population_size", 200)
                use_dual_network = params.get("use_dual_network", True)
                population_profile_id = params.get("population_profile_id")
                realistic_profile_source_path = params.get("realistic_profile_source_path")
                refresh_realistic_profile = params.get("refresh_realistic_profile", False)
                include_public_enrichment = params.get("include_public_enrichment", False)
                include_llm_enrichment = params.get("include_llm_enrichment", False)
                effective_population_size = population_size
                if population_profile_id:
                    profile = load_realistic_population(
                        population_profile_id,
                        source_path=realistic_profile_source_path,
                        refresh_cache=refresh_realistic_profile,
                        include_public_enrichment=include_public_enrichment,
                    )
                    effective_population_size = profile.size
                max_steps = params.get("max_steps", 50)  # 从前端获取最大步数

                # 自动计算并发数（如果未指定）
                max_concurrent = params.get("max_concurrent")
                if max_concurrent is None:
                    max_concurrent = calculate_max_concurrent(effective_population_size)
                logger.info(f"LLM并发数设置: {max_concurrent} (Agent数量: {effective_population_size})")

                # 从前端获取LLM并发参数
                # 使用环境变量中的LLM配置，仅覆盖并发数和超时参数
                llm_config = LLMConfig(
                    max_concurrent=max_concurrent,
                    timeout=params.get("timeout", 60),
                    max_retries=params.get("max_retries", 5),
                    connection_pool_size=params.get("connection_pool_size", 600)
                )

                # 参数兼容解析：新参数名优先，旧参数名兜底
                effective_initial_spread = params.get("initial_negative_spread", params.get("initial_rumor_spread", 0.3))
                effective_debunk_delay = params.get("response_delay", params.get("debunk_delay", 10))
                effective_credibility = params.get("response_credibility", params.get("debunk_credibility", 0.7))

                # 根据是否启用双层网络选择引擎
                if use_dual_network:
                    logger.info(f"使用双层网络引擎, 社群数: {params.get('num_communities', 8)}, LLM模式: {use_llm}")
                    state.engine = SimulationEngineDual(
                        population_size=effective_population_size,
                        cocoon_strength=params.get("cocoon_strength", 0.5),
                        debunk_delay=effective_debunk_delay,
                        initial_rumor_spread=effective_initial_spread,
                        use_llm=use_llm,
                        llm_config=llm_config,
                        num_communities=params.get("num_communities", 8),
                        public_m=params.get("public_m", 3),
                        # 增强版数学模型参数
                        debunk_credibility=effective_credibility,
                        authority_factor=params.get("authority_factor", 0.5),
                        backfire_strength=params.get("backfire_strength", 0.3),
                        silence_threshold=params.get("silence_threshold", 0.3),
                        polarization_factor=params.get("polarization_factor", 0.3),
                        echo_chamber_factor=params.get("echo_chamber_factor", 0.2),
                        population_profile_id=population_profile_id,
                        realistic_profile_source_path=realistic_profile_source_path,
                        refresh_realistic_profile=refresh_realistic_profile,
                        include_public_enrichment=include_public_enrichment,
                        include_llm_enrichment=include_llm_enrichment
                    )
                else:
                    state.engine = SimulationEngine(
                        population_size=effective_population_size,
                        cocoon_strength=params.get("cocoon_strength", 0.5),
                        debunk_delay=effective_debunk_delay,
                        initial_rumor_spread=effective_initial_spread,
                        network_type=params.get("network_type", "small_world"),
                        use_llm=use_llm,
                        llm_config=llm_config,
                        # 增强版数学模型参数
                        debunk_credibility=effective_credibility,
                        authority_factor=params.get("authority_factor", 0.5),
                        backfire_strength=params.get("backfire_strength", 0.3),
                        silence_threshold=params.get("silence_threshold", 0.3),
                        polarization_factor=params.get("polarization_factor", 0.3),
                        echo_chamber_factor=params.get("echo_chamber_factor", 0.2),
                        population_profile_id=population_profile_id,
                        realistic_profile_source_path=realistic_profile_source_path,
                        refresh_realistic_profile=refresh_realistic_profile,
                        include_public_enrichment=include_public_enrichment
                    )

                # 设置进度回调
                state.engine.set_progress_callback(send_progress)

                # 如果有待注入事件，根据事件内容设置初始分布
                if state.pending_knowledge_graph and state.pending_event_content:
                    sentiment = state.pending_knowledge_graph.get("sentiment", "中性")
                    credibility = state.pending_knowledge_graph.get("credibility_hint", "不确定")
                    entity_count = len(state.pending_knowledge_graph.get('entities', []))
                    if hasattr(state.engine, 'set_initial_distribution_from_news'):
                        state.engine.set_initial_distribution_from_news(sentiment, credibility, entity_count)
                        logger.info(f"已根据新闻内容设置初始分布")

                initial_state = state.engine.initialize()

                # LLM persona enrichment
                if hasattr(state.engine, 'async_enrich_personas'):
                    await state.engine.async_enrich_personas()

                # ==================== 自动注入待处理的事件 ====================
                if state.pending_knowledge_graph and state.pending_event_content:
                    logger.info(f"检测到待注入事件，自动注入到引擎: {state.pending_event_content[:50]}...")

                    # 设置知识图谱，启用知识驱动演化
                    entities = state.pending_knowledge_graph.get('entities', [])
                    relations = state.pending_knowledge_graph.get('relations', [])
                    if entities and hasattr(state.engine, 'set_knowledge_graph'):
                        state.engine.set_knowledge_graph(entities, relations, merge=False)
                        logger.info(f"知识驱动演化已启用")

                    # 如果引擎支持设置新闻
                    if hasattr(state.engine, 'set_news'):
                        result = state.engine.set_news(
                            state.pending_event_content,
                            state.pending_event_source or "public",
                            parse_graph=False,
                        )
                        import inspect as _inspect
                        if _inspect.isawaitable(result):
                            await result

                    # 广播事件（触发事件冲击）
                    target_scope = "all"
                    if state.pending_event_source == "public":
                        target_scope = "public_only"
                    elif state.pending_event_source == "private":
                        target_scope = "private_only"

                    sentiment = state.pending_knowledge_graph.get("sentiment", "中性")
                    credibility = state.pending_knowledge_graph.get("credibility_hint", "不确定")
                    state.engine.broadcast_event(state.pending_event_content, target_scope, sentiment=sentiment, credibility=credibility)

                    logger.info(f"待注入事件已成功注入，图谱包含 {len(state.pending_knowledge_graph.get('entities', []))} 个实体")

                    # 清空待注入数据
                    state.pending_knowledge_graph = None
                    state.pending_event_content = None
                    state.pending_event_source = None

                await websocket.send_json({
                    "type": "state",
                    "data": _state_to_dict(initial_state)
                })
                logger.info(f"模拟已启动, LLM模式: {use_llm}, 双层网络: {use_dual_network}")

            elif action == "step":
                # 单步推演
                if state.engine is None:
                    await websocket.send_json({
                        "type": "error",
                        "message": "请先启动模拟"
                    })
                    continue

                try:
                    s = await state.engine.async_step()
                    await websocket.send_json({
                        "type": "state",
                        "data": _state_to_dict(s)
                    })
                except Exception as e:
                    logger.error(f"推演错误: {e}")
                    await websocket.send_json({
                        "type": "error",
                        "message": str(e)
                    })

            elif action == "auto":
                # 自动推演
                if state.engine is None:
                    await websocket.send_json({
                        "type": "error",
                        "message": "请先启动模拟"
                    })
                    continue

                interval = msg.get("interval", 2000)
                auto_mode = True
                auto_task = asyncio.create_task(auto_step_loop(interval))
                logger.info(f"自动推演已启动, 间隔 {interval}ms")

            elif action == "pause":
                # 暂停自动推演（保留引擎状态，可恢复）
                auto_mode = False
                if auto_task:
                    auto_task.cancel()
                    auto_task = None
                logger.info("自动推演已暂停")

            elif action == "resume":
                # 恢复自动推演
                if state.engine is None:
                    await websocket.send_json({
                        "type": "error",
                        "message": "请先启动模拟"
                    })
                    continue
                if state.engine.step_count >= max_steps:
                    await websocket.send_json({
                        "type": "error",
                        "message": "推演已完成，无法恢复"
                    })
                    continue
                interval = msg.get("interval", 2000)
                auto_mode = True
                auto_task = asyncio.create_task(auto_step_loop(interval))
                logger.info(f"自动推演已恢复, 间隔 {interval}ms")

            elif action == "stop":
                # 停止自动推演（终止推演）
                auto_mode = False
                if auto_task:
                    auto_task.cancel()
                    auto_task = None
                logger.info("自动推演已停止")

            elif action == "finish":
                # 生成报告
                if state.engine is None:
                    await websocket.send_json({
                        "type": "error",
                        "message": "请先启动模拟"
                    })
                    continue

                report_path = state.engine.generate_report()
                report_path_safe = report_path.replace("\\", "/") if report_path else None
                await websocket.send_json({
                    "type": "report",
                    "data": {
                        "success": True,
                        "report_path": report_path_safe,
                        "report_filename": os.path.basename(report_path) if report_path else None
                    }
                })

    except WebSocketDisconnect:
        logger.info("WebSocket 断开")
        auto_mode = False
    except Exception as e:
        logger.error(f"WebSocket 错误: {e}")
    finally:
        auto_mode = False
        if auto_task:
            auto_task.cancel()
        if active_websockets.get(client_key) is websocket:
            active_websockets.pop(client_key, None)
