"""
Environment Layer Module - 分层环境系统

基于 AgentSociety 架构设计:
- AlgorithmEnv: 算法推荐环境（信息茧房）
- SocialEnv: 社交网络环境
- TruthEnv: 官方辟谣环境
- EnvRouter: 统一环境访问路由
"""

from .base import EnvBase, EnvTool, ToolKind, tool
from .router import EnvRouter
from .algorithm_env import AlgorithmEnv
from .social_env import SocialEnv
from .truth_env import TruthEnv

__all__ = [
    "EnvBase",
    "EnvTool",
    "ToolKind",
    "tool",
    "EnvRouter",
    "AlgorithmEnv",
    "SocialEnv",
    "TruthEnv",
]
