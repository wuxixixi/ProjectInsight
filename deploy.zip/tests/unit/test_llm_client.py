"""
LLM 客户端单元测试
测试异步 LLM 调用和并发控制
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock
import json

from backend.llm.client import LLMClient, LLMConfig, create_llm_config_from_env


class TestLLMConfig:
    """测试 LLM 配置"""

    def test_default_config(self):
        """测试默认配置"""
        config = LLMConfig()

        # 默认值从环境变量读取，验证它们在合理范围内
        assert config.max_concurrent >= 10  # 至少支持一定并发
        assert config.max_concurrent <= 1000  # 但不应过大
        assert config.timeout >= 30  # 至少30秒超时
        assert config.timeout <= 300  # 但不应太长
        assert config.max_retries >= 1  # 至少重试1次
        assert config.max_retries <= 20  # 但不应太多
        assert config.connection_pool_size >= 100  # 连接池足够大

    def test_custom_config(self):
        """测试自定义配置"""
        config = LLMConfig(
            base_url="http://custom:8000/v1",
            api_key="test-key",
            model="custom-model",
            max_concurrent=5
        )

        assert config.base_url == "http://custom:8000/v1"
        assert config.api_key == "test-key"
        assert config.model == "custom-model"
        assert config.max_concurrent == 5

    def test_prefixed_report_config(self):
        """测试按前缀读取专报配置"""
        with patch.dict("os.environ", {
            "LLM_BASE_URL": "http://main/v1",
            "LLM_API_KEY": "main-key",
            "LLM_MODEL": "DeepSeek-V3.2",
            "LLM_TIMEOUT": "60",
            "LLM_MAX_RETRIES": "5",
            "REPORT_LLM_BASE_URL": "http://report/v1",
            "REPORT_LLM_API_KEY": "report-key",
            "REPORT_LLM_MODEL": "DeepSeek-R1-0528-64k",
            "REPORT_LLM_TIMEOUT": "120",
            "REPORT_LLM_MAX_RETRIES": "2",
            "REPORT_LLM_TEMPERATURE": "0.5",
            "REPORT_LLM_MAX_TOKENS": "2000",
        }, clear=False):
            config = create_llm_config_from_env("REPORT_LLM")

        assert config.base_url == "http://report/v1"
        assert config.api_key == "report-key"
        assert config.model == "DeepSeek-R1-0528-64k"
        assert config.timeout == 120
        assert config.max_retries == 2
        assert config.temperature == 0.5
        assert config.max_tokens == 2000


class TestLLMClientInit:
    """测试 LLM 客户端初始化"""

    def test_init_with_default_config(self):
        """测试默认配置初始化"""
        client = LLMClient()

        assert client.config is not None
        # issue #1030: semaphore is now lazy-init, accessed via property
        assert client.semaphore is not None  # property triggers lazy init
        assert client._session is None

    def test_init_with_custom_config(self):
        """测试自定义配置初始化"""
        config = LLMConfig(max_concurrent=5)
        client = LLMClient(config)

        assert client.config.max_concurrent == 5


class TestLLMClientChatJson:
    """测试 LLM 客户端 JSON 解析功能
    
    Issue #1254: 修复测试使用实际方法而非手动实现
    """

    def test_parse_json_response(self):
        """测试 JSON 响应解析 - 使用实际方法"""
        client = LLMClient()
        content = '{"new_opinion": 0.5, "reasoning": "test"}'

        # Issue #1254: 使用实际方法而非 json.loads
        result = client._parse_json_content(content)

        assert result["new_opinion"] == 0.5
        assert result["reasoning"] == "test"

    def test_parse_json_with_markdown_block(self):
        """测试带 Markdown 代码块的 JSON 解析 - 使用实际方法"""
        client = LLMClient()
        content = '```json\n{"new_opinion": 0.3}\n```'

        # Issue #1254: 使用实际方法
        result = client._parse_json_content(content)

        assert result["new_opinion"] == 0.3

    def test_parse_json_with_simple_block(self):
        """测试带简单代码块的 JSON 解析 - 使用实际方法"""
        client = LLMClient()
        content = '```\n{"new_opinion": -0.2}\n```'

        # Issue #1254: 使用实际方法
        result = client._parse_json_content(content)

        assert result["new_opinion"] == -0.2


class TestConcurrencyControl:
    """测试并发控制"""

    @pytest.mark.asyncio
    async def test_semaphore_limits_concurrency(self):
        """测试信号量限制并发"""
        config = LLMConfig(max_concurrent=2)
        client = LLMClient(config)

        # 直接测试信号量行为
        call_count = 0
        max_concurrent = 0
        current_concurrent = 0

        async def track_concurrency():
            nonlocal call_count, max_concurrent, current_concurrent
            async with client.semaphore:
                current_concurrent += 1
                call_count += 1
                max_concurrent = max(max_concurrent, current_concurrent)
                await asyncio.sleep(0.05)
                current_concurrent -= 1

        # 创建 5 个并发任务
        tasks = [track_concurrency() for _ in range(5)]
        await asyncio.gather(*tasks)

        # 最大并发数不应超过配置值
        assert max_concurrent <= config.max_concurrent

    @pytest.mark.asyncio
    async def test_semaphore_allows_multiple_batches(self):
        """测试信号量允许多批次执行"""
        config = LLMConfig(max_concurrent=3)
        client = LLMClient(config)

        completed = []

        async def track_task(task_id):
            async with client.semaphore:
                await asyncio.sleep(0.02)
                completed.append(task_id)

        # 创建 6 个任务
        tasks = [track_task(i) for i in range(6)]
        await asyncio.gather(*tasks)

        # 所有任务都应完成
        assert len(completed) == 6


class TestGetLLMClient:
    """测试全局客户端获取"""

    def test_get_llm_client_returns_instance(self):
        """测试获取客户端实例"""
        from backend.llm.client import get_llm_client

        # 重置全局实例
        import backend.llm.client
        backend.llm.client._llm_client = None

        client = get_llm_client()

        assert isinstance(client, LLMClient)

        # 清理
        backend.llm.client._llm_client = None


class TestClientContextManager:
    """测试客户端上下文管理器"""

    @pytest.mark.asyncio
    async def test_context_manager_creates_session(self):
        """测试上下文管理器创建会话"""
        client = LLMClient()

        assert client._session is None

        async with client:
            assert client._session is not None

        assert client._session is None

    @pytest.mark.asyncio
    async def test_context_manager_creates_fresh_session(self):
        """测试每次进入创建新会话"""
        client = LLMClient()

        async with client:
            session1 = client._session
            assert session1 is not None

        # 退出后 session 应该被清理
        assert client._session is None

        async with client:
            session2 = client._session
            assert session2 is not None
